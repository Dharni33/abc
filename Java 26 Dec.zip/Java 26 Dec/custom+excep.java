class My_Exc extends Exception{
	public My_Exc(String alert){
		//super(alert);
		System.out.println(alert);
	}
}

class A{
	
	int z, y;
	int a[]= {2,3,4};
	
	void div(){
		y= 9;
		try{
			if(y==9){
				throw new My_Exc(" Divide by 9 not allowed");
			}
		}
		
		catch(My_Exc e){
			System.out.println("Throwing a custom exception");
			//throw new My_Exc("Throwing a custom exception");
		}
		catch (ArithmeticException e){
			System.out.println("Throwing a arithmetic exception");
			//throw new ArithmeticException("Throwing a arithmetic exception");
		}
		
		catch (ArrayIndexOutOfBoundsException e){
			System.out.println("Throwing a array index exception");
			//throw new ArrayIndexOutOfBoundsException("Throwing a array index exception");
		}
		
	}
	
	
	public static void main(String ar[]){
		B b = new B();
	
		b.div();
		
		System.out.println("OK bye.");
	}
}