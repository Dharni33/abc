interface A{
	void show();
}

class B implements A{
	public void show(){
		System.out.println("Class B show()");
	}
	
	public static void main(String ar[]){
		B b= new B();
		b.show();
	}
}