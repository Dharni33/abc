abstract class A{
	
	abstract void show();
}

abstract class B extends A{
	//void show() {
	//	System.out.println("Class B");
	//}

	
}


class C extends B{
	void show() {
		System.out.println("Class C");
	}
	
	public static void main(String ar[]) {
		
		C b= new C();
		b.show();
	}
	
}