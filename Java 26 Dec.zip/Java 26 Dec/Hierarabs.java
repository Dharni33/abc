abstract class A{
	
	abstract void show();
}

class B extends A{
	void show() {
	System.out.println("Class B");
	}

	
}


class C extends A{
	void show() {
		System.out.println("Class C");
	}
	
	public static void main(String ar[]) {
		
		B b= new B();
		b.show();
		
		C c= new C();
		c.show();
		
	}
	
}