class A{
	int z;
	int a[]= {2,3,4};
	void div(){
		
		try{
			z= a[1]/0;
			System.out.println(z);
		}
		
		catch(ArithmeticException e){
			System.out.println("Divide by 0 error");
		}
		
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println("Please check the array index");
		}
		
		finally{
			System.out.println("Completed");
		}
	}
}

class B extends A{
	public static void main(String ar[]){
		B b = new B();
		b.div();
	}
}