abstract class A{
	
	abstract void show();
}

class B extends A{
	void show() {
		System.out.println("Class B");
	}
	
	public static void main(String ar[]) {
		
		B b= new B();
		b.show();
	}
	
}