interface A{
	void show();
}

interface C{
	void add();
}

class B implements A,C{
	public void show(){
		System.out.println("Class B show()");
	}
	
	public void add(){
		System.out.println("Class B add()");
	} 
	
	public static void main(String ar[]){
		B b= new B();
		b.show();
		b.add();
	}
}