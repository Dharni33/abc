interface A{
	default void show(){
		System.out.println("Interface A show()");
	}
	
}

interface C{
	static void show(){
		System.out.println("Interface C add()");
	}
}

class D{
	void show1(){
		System.out.println("Class D");
	}
}

class B extends D implements A,C{
	/*public void show(){
		System.out.println("Class B show()");
	}*/
	
	/*public void add(){
		System.out.println("Class B add()");
	}*/ 
	/*public void show(){
			A.super.show();
		}*/
	public static void main(String ar[]){
		B b= new B();
		C.show();
		
		
		//b.add();
		b.show1();
	}
}