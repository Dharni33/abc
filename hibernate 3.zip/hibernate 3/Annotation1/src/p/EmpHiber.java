package p;
import java.util.*;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.Transaction;
public class EmpHiber {
	
	public static void main(String ar[]) {
		Configuration cfg= new Configuration();
		cfg.configure("hibernate.cfg.xml");
		//SessionFactory sf= cfg.buildSessionFactory();
		SessionFactory sf= new AnnotationConfiguration().addAnnotatedClass(Emp1.class).configure().buildSessionFactory();
		Session ses= sf.openSession();
		Transaction ts= ses.beginTransaction();
		ts.begin();
		
		
		Emp1 e1= new Emp1();
		e1.setId("101");
		e1.setEcode("1000");
		e1.setEname("Dharni");
		ses.persist(e1);
		System.out.println("success");
		ts.commit();
	}
}
