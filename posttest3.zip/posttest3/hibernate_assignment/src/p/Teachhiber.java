package p;
import java.util.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.Transaction;
public class Teachhiber {
	
	public static void main(String ar[]) {
		Configuration cfg= new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf= cfg.buildSessionFactory();
		Session ses= sf.openSession();
		Transaction ts= ses.beginTransaction();
		ts.begin();
		
		Dept re= new Dept();
		re.setTid("4");
		re.setTname("Dharni");
		re.setDept("Science1");
		re.setDname("Science");
		re.setDid("100");
		
		ses.persist(re);
		ses.flush();
		ses.clear();
		System.out.println("success");
		
		Course co= new Course();
		co.setTid("3");
		co.setTname("Vks");
		co.setDept("Science2");
		co.setCid("1000");
		co.setCname("Organic");
		ses.persist(co);
		ses.flush();
		ses.clear();
		System.out.println("success");
		

		
	
		

	}
}
