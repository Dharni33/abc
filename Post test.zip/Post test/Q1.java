import java.util.Scanner;

class Q1 {
  public static void dupchar(String str) {
    String s1 = str.toLowerCase();
    String s = s1.replaceAll("\\s","");
   StringBuffer in = new StringBuffer(s);
   int length = in.length();
   int count;
   boolean check;
   for (int i = 0; i < length; i++) {
     count = 0;
     check = false;
     for (int j = i + 1; j < length; j++) {
       if (in.charAt(i) == in.charAt(j)) {
           
         in.deleteCharAt(j);
         check = true;
         j--;
         length--;
         count++;
       }
     }
     if(count+1!=1)
     System.out.println("Repeated characters "+in.charAt(i)+" = "+(count+1));
   }
  }
 
 public static void main(String[] args) {
  Scanner sc = new Scanner(System.in);
  System.out.println("Enter a String");
  String input = sc.nextLine();
  Q1.dupchar(input);

}
}