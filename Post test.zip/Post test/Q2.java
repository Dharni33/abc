import java.util.Scanner;

public class Q2 {

	void dupchar(String str){
        String r = "";
	
        StringBuilder sb = new StringBuilder();
		for (char c : str.toCharArray()) {
		if (c != ' ') {
			sb.append(c);
			}
	}
	System.out.println(sb.toString());
    }

		public static void main(String args[]) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a string:");
		String s= sc.nextLine();
		Q2 d= new Q2();
		d.dupchar(s);
		}
}
		
 