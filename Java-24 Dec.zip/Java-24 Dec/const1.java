class C{
	int x;
	static int p;

	C(int x){
		this.x=x;
		}
	C(){
		x=20;
		}

	void show(){
		System.out.println("show()");
		System.out.println("x=" +x);
		}
	
	public static void main(String args[])
	{
		C c1= new C();
		c1.show();
		C c2 =new C(30);
		c2.show();
}
}