import java.util.*;
import java.util.Scanner;
class Bank{
	String name;
	int accno;
	String type;
	double amount;
	double balance;
	
	Bank(String name, int accno, String type, double balance){
		this.name=name;
		this.accno = accno;
		this.type = type;
		this.balance= balance;
	}
	
	public String getName(){
		return this.name;
	}
	
	public void setName(String name){
		this.name= name;
	}
	
	public int getAccno(){
		return this.accno;
	}
	
	public void setAccno(int accno){
		this.accno= accno;
	}
	
	public String getType(){
		return this.type;
	}
	
	public void setType(String type){
		this.type= type;
	}
	
	public double getBalance(){
		return this.balance;
	}
	
	public void setBalance(double balance){
		this.balance= balance;
	}
	
	
	void deposit(double amt){
		balance = balance+ amt;
	}
	
	void withdraw(double withdraw){
		balance=balance-withdraw;
	}
	
	void show(){
		System.out.println("Name:"+ name+ "Balance:"+ balance);

	}

	public static void main(String ar[]){
		Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        String type = sc.nextLine();
		int accno= sc.nextInt();
		double balance= sc.nextDouble();
		
		Bank b1= new Bank(name,accno,type,balance);
		double amount= sc.nextDouble();
		b1.deposit(amount);
		double withdraw= sc.nextDouble();
		b1.withdraw(withdraw);
		b1.show();
		
		
	}
}	
	
