class B{
	int p;
	B(int r){
		p=r;
	}
}

class A extends B {
	int x;
	A(){
		super(30);
		x=10;
	}
	

	public static void main(String ar[]){
		A a1= new A();
		//a1.show();
		System.out.println("x="+a1.x);
		System.out.println("p="+a1.p);
		
	}
}