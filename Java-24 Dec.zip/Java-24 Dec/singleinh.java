class B{
	int p;
	void show(){
		p=20;
		System.out.println("Class B");
	}
}

class A extends B {
	int x;
	void show(){
		x=10;
		super.show();
		System.out.println("Class A");

	}

	public static void main(String ar[]){
		A a1= new A();
		a1.show();
		System.out.println("x="+a1.x);
		System.out.println("p="+a1.p);
		
	}
}