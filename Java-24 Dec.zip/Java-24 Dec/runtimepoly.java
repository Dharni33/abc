class B{
	int p;
	void show(){
		System.out.println("class B");
	}
}

class A extends B {
	void show(){
		System.out.println("class A");
	}
	
	public static void main(String ar[]){
		B a1= new A();
		a1.show();
	
	}
}