class B{
	int p;
	void show(){
		p=20;
		System.out.println("Class B");
	}
}

class C extends B{
	int z;
	void show(){
		z=30;
		super.show();
		System.out.println("Class C");
	}
}

class A extends C {
	int x;
	void show(){
		x=10;
		super.show();
		System.out.println("Class A");

	}

	public static void main(String ar[]){
		A a1= new A();
		a1.show();
		//a1.show1();
		System.out.println("x="+a1.x);
		System.out.println("x="+a1.z);
		System.out.println("p="+a1.p);
		
		
	}
}