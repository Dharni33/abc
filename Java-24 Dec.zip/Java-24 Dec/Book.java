import java .util.*;
class Book{
	int stockpos;
	String title, author, publisher;
	int price;
	Book(String title, String author,String publisher,int price, int stockpos){
		this.title=title;
		this.author=author;
		this.publisher=publisher;
		this.price=price;
		this.stockpos= stockpos;
	}
	
	
	
	
	
	public static void main(String ar[]){
		List <Book> list= new ArrayList<Book>();
		Book b1= new Book("A","Dharni","ABC",25,200);
		Book b2= new Book("B","Dhiren","XYZ",40,100);
		Book b3= new Book("C","Pooja","MNO",100,1010);
		
		list.add(b1);
		list.add(b2);
		list.add(b3);
		
		System.out.println("Enter the title and author name");
		Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        String author = sc.nextLine();
		
		for(int i=0;i< list.size();i++){
			System.out.println(list.get(i));
		}
		
		
	}
}