package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;


public class MyCon {
	public static Connection getCon() {
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
	    String dbname= "db1";
		String driver= "com.mysql.jdbc.Driver";
		String username= "root";
		String password="root";
		
		try {
		Class.forName(driver);
		conn= DriverManager.getConnection(url+dbname,username,password);}
		catch(Exception e){
			e.printStackTrace();
		}
		return conn;
		
	}
}
