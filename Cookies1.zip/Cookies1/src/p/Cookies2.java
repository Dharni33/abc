package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Cookies2 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		try{
			PrintWriter out = response.getWriter();
			String name1= null;
			String name2= null;
			Cookie cr[]= request.getCookies();
			
			if(cr!=null) {
				for(int i=0; i<cr.length; i++)
				{name1=cr[i].getName();
				name2=cr[i].getValue();
				out.println(name1+name2);}
			}
			else {
				out.print("No Cookie for you!");
			}
			
		}
		
		catch(Exception e){
			e.printStackTrace();
		}
}
}