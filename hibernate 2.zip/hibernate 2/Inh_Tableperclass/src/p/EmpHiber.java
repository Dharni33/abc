package p;
import java.util.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.Transaction;
public class EmpHiber {
	
	public static void main(String ar[]) {
		Configuration cfg= new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf= cfg.buildSessionFactory();
		Session ses= sf.openSession();
		Transaction ts= ses.beginTransaction();
		ts.begin();
		
		Reg_emp re= new Reg_emp();
		re.setId("105");
		re.setEcode("1007");
		re.setEname("Aastha");
		re.setBonus(100000);
		re.setSalary(300000);
		ses.persist(re);
		ses.flush();
		ses.clear();
		System.out.println("success");
		
		Con_emp co= new Con_emp();
		co.setId("106");
		co.setEcode("1008");
		co.setEname("Ash");
		co.setCommission(10);
		co.setPeriod(4);
		ses.persist(co);
		ses.flush();
		ses.clear();
		System.out.println("success");
		
		ts.commit();
		
		/*Query query= ses.createQuery("from Emp1");
		
		List e1= query.list();
		Iterator itr= e1.iterator();
		while(itr.hasNext()) 
		{Emp1 e2= (Emp1)itr.next();
		System.out.println("Ename: "+ e2.getEname());
		System.out.println("ID: "+ e2.getId());
		}
		*/
		

	}
}
