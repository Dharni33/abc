package p;
import java.util.*;

import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.criterion.Criterion;
import org.hibernate.Transaction;
public class EmpHiber {
	
	public static void main(String ar[]) {
		Configuration cfg= new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf= cfg.buildSessionFactory();
		Session ses= sf.openSession();
		Transaction ts= ses.beginTransaction();
		ts.begin();
		Criteria crit= ses.createCriteria(Emp1.class);
		Criterion cn= Restrictions.gt("salary", Integer.valueOf(20000));
		crit.add(cn);
		List l= crit.list();
		System.out.println("List total size"+l.size());
		Iterator itr= l.iterator();
		
		while(itr.hasNext()) 
		{Emp1 e2= (Emp1)itr.next();
		System.out.println("Ename: "+ e2.getEname());
		System.out.println("ID: "+ e2.getId());
		System.out.println("Salary: "+ e2.getSalary());
		}
		System.out.println("success");
		
		ts.commit();
		
		/*Query query= ses.createQuery("from Emp1");
		
		List e1= query.list();
		Iterator itr= e1.iterator();
		while(itr.hasNext()) 
		{Emp1 e2= (Emp1)itr.next();
		System.out.println("Ename: "+ e2.getEname());
		System.out.println("ID: "+ e2.getId());
		}
		*/
		

	}
}
