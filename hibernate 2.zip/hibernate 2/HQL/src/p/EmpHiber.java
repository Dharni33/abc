package p;
import java.util.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.Transaction;
public class EmpHiber {
	
	public static void main(String ar[]) {
		Configuration cfg= new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf= cfg.buildSessionFactory();
		Session ses= sf.openSession();
		Transaction ts= ses.beginTransaction();
		ts.begin();
		
		
		/*Query query= ses.createQuery("from Emp1");
		
		List e1= query.list();
		Iterator itr= e1.iterator();
		while(itr.hasNext()) 
		{Emp1 e2= (Emp1)itr.next();
		System.out.println("Ename: "+ e2.getEname());
		System.out.println("ID: "+ e2.getId());
		}*/
		
		//update
		/*Query q= ses.createQuery("update Emp1 set ename=:n where id=:i");
		q.setParameter("n","Vineet");
		q.setParameter("i", "101");
		int z= q.executeUpdate();
		System.out.println("z:"+z);*/
		
		//Delete
		/*String s="101";
		Query q= ses.createQuery("delete from Emp1 where id='"+s+"'");
		int z= q.executeUpdate();
		System.out.println("z:"+z);*/
		
		Query q= ses.createQuery("Select sum(salary) from Emp1");
			List<Integer>list= q.list();
			System.out.println("Sum: "+ list.get(0));
			
			Query q1= ses.createQuery("Select avg(salary) from Emp1");
			List<Integer>list1= q1.list();
			System.out.println("Avg: "+ list1.get(0));
		
			Query q2= ses.createQuery("Select max(salary) from Emp1");
			List<Integer>list2= q2.list();
			System.out.println("Max: "+ list2.get(0));
		
			Query q3= ses.createQuery("Select count(id) from Emp1");
			List<Integer>list3= q3.list();
			System.out.println("Count: "+ list3.get(0));
		ts.commit();
	}
}
