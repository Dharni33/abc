package p;
import java.util.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.Transaction;
public class EmpHiber {
	
	public static void main(String ar[]) {
		Configuration cfg= new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf= cfg.buildSessionFactory();
		Session ses= sf.openSession();
		Transaction ts= ses.beginTransaction();
		ts.begin();
		
		
		Emp1 e1= new Emp1();
		e1.setId("101");
		e1.setEcode("1021");
		e1.setEname("Dharni");
		e1.setSalary("200000");
		String eid= (String)ses.save(e1);
		System.out.println("success");
		ts.commit();
		
		//SELECT QUERY
		/*List e= ses.createQuery("from Emp1").list();
		Iterator itr= e.iterator();
		while(itr.hasNext())
		{
			Emp1 em1= (Emp1)itr.next();
			System.out.println("eid="+em1.getId());
			System.out.println("ecode="+em1.getEcode());
		}
		ts.commit();*/
		
		//UPDATE QUERY
		
		/*Emp1 em1= (Emp1)ses.get(Emp1.class,"4444");
		em1.setEname("Hrishi");
		ses.update(em1);
		ts.commit();*/
		
		//DELETE Query
		
		/*Object o= ses.load(Emp1.class, new String("4444"));
		Emp1 emp= (Emp1)o;
		ses.delete(emp);
		ts.commit();*/
		
		
	}
}
