package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SendRequest extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		try{
			PrintWriter out = response.getWriter();
			String name1= request.getParameter("user");
			String password1= request.getParameter("password");
			name1= name1.trim();
			out.println("your name is stored");
			if(name1.equals("abc") && password1.equals("abc")) {
				out.println("VALID USER");
		}
			else{
				response.sendRedirect("Error.html");
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
}
}