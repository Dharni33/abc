package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet {
	
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		try{
			PrintWriter out = response.getWriter();
			String user= request.getParameter("user");
			String passw= request.getParameter("password");
			
			if(user.equals("abc") && passw.equals("abc")) {
				out.println("VALID USER");
				out.println("<html><body>");
				out.println("<form name='iii' method='get' action= 'pass2'>");
				out.println("<input type='text' placeholder='ECODE' name='ecode'>");
				out.println("<input type='text' placeholder='ENAME' name='ename'>");
				out.println("<br><input type='submit' value='update' name='click'>");
				out.println("<input type='submit' value='delete' name='click'>");
				out.println("</form></body></html>");
			}
			
			else {
				out.println("INVALID USER");
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
}
}