package p;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Controller1 {
	@RequestMapping("/v1")
	public String show() {
		System.out.println("hello");
		return "first";
		
	}

	@RequestMapping("/v3")
	public String show2() {
		System.out.println("hello");
		return "second";
		
	}
	
}
