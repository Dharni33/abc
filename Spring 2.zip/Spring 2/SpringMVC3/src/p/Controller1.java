package p;

import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Controller1 {
	@RequestMapping("/v1")
	/*public String dis(HttpServletRequest request, Model m) {
		System.out.println("Hello");
		String ecode= request.getParameter("ecode");
		String ename= request.getParameter("ename");
		m.addAttribute("s1", ecode);
		m.addAttribute("s2", ename);
		return "first";

	}*/
	public String dis(HttpServletRequest request, ModelMap m) {
	System.out.println("Hello");
	String ecode= request.getParameter("ecode");
	String ename= request.getParameter("ename");
	m.put("s1", ecode);
	m.put("s2", ename);
	return "first";}
	
	@RequestMapping("/v2")
	public String dis1(@RequestParam("ecode")String ecode,@RequestParam("ename")String ename, Model m) {
		System.out.println("Hello");
		m.addAttribute("s1", ecode);
		m.addAttribute("s2", ename);
		return "first";

	}

}

