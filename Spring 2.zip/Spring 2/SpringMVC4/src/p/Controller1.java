package p;

import java.awt.List;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Controller1 {
	@RequestMapping("/v1")
	
	public ModelAndView dis() {
		ArrayList l= new ArrayList();
		l.add(new Emp("abc",9000));
		l.add(new Emp("xyz",1000));
	return new ModelAndView("view","list1",l);}
	
	@RequestMapping("/v2")
	public ModelAndView form() {
		Emp e= new Emp("www",888);
		//return new ModelAndView("empform","o",new Emp("ooo",111));
		return new ModelAndView("display","o",e);
	}

}

