class Demo implements Runnable{
	int i;
	String n;
	
	public void run(){
		
		for(i=0; i<5; i++){
			System.out.println("child thread" + "i="+ i);
			System.out.println("child thread" + "finished");
			
		}
	}
}

class DemoThread{
	public static void main(String args[]){
		Demo d = new Demo();
		Demo d1 = new Demo();
		Thread t= new Thread(d);
		Thread t1= new Thread(d1);
		t.start();
		t1.start();
		
	}
}