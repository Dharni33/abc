import java.util.Scanner;
public class Sc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1 =  new Scanner(System.in);
		System.out.println("Enter String");
		String str = sc1.next();
		System.out.println("Entered value is "+str);
		System.out.println("Enter byte");
		Byte b = sc1.nextByte();
		System.out.println("Entered value is "+b);
		System.out.println("Enter int");
		int i = sc1.nextInt();
		System.out.println("Entered value is "+i);
		System.out.println("Enter Float");
		float f  = sc1.nextFloat();
		System.out.println("Entered value is "+f);
		System.out.println("Enter char");
		String c = sc1.next();
		System.out.println("Entered value is "+c);
		

	}

}
 