class A {
	void s(){
		System.out.println("hello");
		try{
			Thread.sleep(1000);
		}
		catch(InterruptedException e){
			System.out.println("child thread interrupted hello");
		}
		System.out.println("Ok Bye");
	}
	
	void s2(){
		System.out.println("S2");
	}
}

class Demo implements Runnable{
	int i;
	A a; 
	Demo(A a){
		this.a=a;
	}
	
	public void run(){
		
		synchronized(a){
			a.s();
		}
	}
}
	 
	
	

class DemoThread{
	public static void main(String args[]){
		A a1= new A();
		Demo d = new Demo(a1);
		
		Thread t= new Thread(d);
		t.start();
		Thread t1= new Thread(d);
		
		t1.start();
		
	}
}