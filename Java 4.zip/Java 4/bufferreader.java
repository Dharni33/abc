import java.io.*;

class UserInput {

	public static void main(String[] args) throws IOException {
		
		int i;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter your name");
		System.out.println("Name : "+br.readLine());
	}

}