import java.io.*;

class FReader
{
int i;

void myRead() throws IOException
{
FileReader f = new FileReader("myfile.txt");

do
{
i = f.read();
if(i!=-1)
{
System.out.println((char)i);
}
}while(i!=-1);

}



public static void main(String args[])
{
try{
FReader f2 = new FReader();
f2.myRead();
}
catch(IOException e)
{
System.out.println("IOException occurred");
}

}
}