import java.io.*;

class FOS
{
	static int i;
	
	void myRead() throws IOException
	{
		FileInputStream f = new FileInputStream("myfile.txt");

		do
		{
			i = f.read();
			if(i!=-1)
			{
				System.out.println((char)i);
			}
		}while(i!=-1);
		
	}
	
	void myWrite(String s) throws IOException
	{
		
		byte b[] = s.getBytes();
		
		byte b1[] ={90,23};
		
		try
		{
			FileOutputStream fo = new FileOutputStream("myfile.txt");
			
			fo.write(b);
			
			fo.close();
		}
		catch(FileNotFoundException e)
		{
			System.out.println("error");
		}
		
	}
	
	public static void main(String args[]) throws IOException
	{
		String s ="i am Dharni";
		FOS f1 = new FOS();
		try{
		f1.myWrite(s);
		f1.myRead();
		}
		catch(IOException e)
		{
			System.out.println("IOException occurred");
		}
	}
}