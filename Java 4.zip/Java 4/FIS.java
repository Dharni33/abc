import java.io.*;

class FIS
{
int i;

void myRead() throws IOException
{
FileInputStream f = new FileInputStream("myfile.txt");

do
{
i = f.read();
if(i!=-1)
{
System.out.println((char)i);
}
}while(i!=-1);

}



public static void main(String args[])
{
try{
FIS f2 = new FIS();
f2.myRead();
}
catch(IOException e)
{
System.out.println("IOException occurred");
}

}
}