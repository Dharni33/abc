class For_each
{
	public static void main(String ar[])
	{
		int x[]={10,20,9};
		for(int i:x)
		{
			System.out.println(i);
		}
	}
	
	
}