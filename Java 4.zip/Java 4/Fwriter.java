import java.io.*;

class Fwriter
{
int i;

void myWrite(String s) throws IOException
	{
		
		byte b[] = s.getBytes();
		
		byte b1[] ={90,23};
		
		try
		{
			FileWriter fo = new FileWriter("myfilewriter.txt");
			
			fo.write(s);
			
			fo.close();
		}
		catch(FileNotFoundException e)
		{
			System.out.println("error");
		}
		
	}
	



public static void main(String args[])
{
try{
Fwriter f2 = new Fwriter();
f2.myWrite("I am Deloitted to be here");
}
catch(IOException e)
{
System.out.println("IOException occurred");
}

}
}