class Demo extends Thread{
	int i;
	String n;
	Demo(){
		start();
	}
	
	public void run(){
		
		System.out.println("hello");
		try{
			sleep(10000);
		}
		catch(InterruptedException e){
			System.out.println("child thread interrupted hello");
		}
		System.out.println("Ok Bye");
	}
}

class DemoThread{
	public static void main(String args[]){
		Demo d = new Demo();
		Demo d1 = new Demo();
	}
}