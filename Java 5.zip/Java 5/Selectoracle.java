package p;

import java.sql.*;

public class Selectoracle {
	public static void main(String ar[]) {
		Connection conn=null;
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
		Statement sm= conn.createStatement();
		ResultSet rs= sm.executeQuery("Select * from emp3");
		while(rs.next())
		{
			String f1= rs.getString("ecode");
			String f= rs.getString("ename");
			System.out.println(f1);
			System.out.println(f);
		}
		conn.close();
		}
	
	catch(Exception e) {
		System.out.println("Failed!");
		e.printStackTrace();
		return;
	}
	
}
}


