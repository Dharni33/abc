package p;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Concat {
	void show() {
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
	    String dbname= "db1";
		String driver= "com.mysql.jdbc.Driver";
		String username= "root";
		String password="root";
		
	
	
	try {
		Class.forName(driver);
		conn= DriverManager.getConnection(url+dbname,username,password);
		Statement sm= conn.createStatement();
		String s ="001";
		String s1= "Dharni";
		ResultSet rs= sm.executeQuery("Select * from emp3 where ecode= '"+s+"'and ename= '"+s1+"'");
		while(rs.next())
		{
			String f1= rs.getString(1);
			String f= rs.getString(2);
			System.out.println(f1);
			System.out.println(f);
		}
		conn.close();
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
		
	}
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Concat i= new Concat();
		i.show();
	}

}



