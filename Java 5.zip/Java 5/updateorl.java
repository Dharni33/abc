package p;

import java.sql.*;
import java.util.Scanner;

public class updateorl {
	public static void main(String ar[]) {
		Connection conn=null;
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
		PreparedStatement ps = conn.prepareStatement("update emp3 set ename=? where ecode=?");
		conn.setAutoCommit(false);
		Scanner sc= new Scanner(System.in);
		String a= sc.nextLine();
		String b= sc.nextLine();
		ps.setString(1, a);
		ps.setString(2,b);
		
		int x  = ps.executeUpdate();
		System.out.println(x +" rows inserted");
		conn.close();
		System.out.println("Disconnected from database");
		conn.close();
		}
	
	catch(Exception e) {
		System.out.println("Failed!");
		e.printStackTrace();
		return;
	}
	}
}
