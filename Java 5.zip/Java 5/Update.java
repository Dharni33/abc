package p;
import java.sql.*;
import java.util.Scanner;
public class Update {
	void show(String a, String b) {
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
	    String dbname= "db1";
		String driver= "com.mysql.jdbc.Driver";
		String username= "root";
		String password="root";
		
	
	
	try {
		Class.forName(driver);
		conn= DriverManager.getConnection(url+dbname,username,password);
		
		
		PreparedStatement ps = conn.prepareStatement("update emp3 set ename=? where ecode= ?");
		
		ps.setString(1, a);
		ps.setString(2,b);
		
		int x  = ps.executeUpdate();
		System.out.println(x +" rows inserted");

		conn.close();
		System.out.println("Disconnected from database");
		
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
		
	}
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		String a= sc.nextLine();
		String b= sc.nextLine();
		Update i= new Update();
		i.show(a,b);
	}

}

