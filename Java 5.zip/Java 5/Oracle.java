package p;

import java.sql.*;

public class Oracle {
	public static void main(String ar[]) {
		Connection conn=null;
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
		
		}
	
	catch(Exception e) {
		System.out.println("Failed!");
		e.printStackTrace();
		return;
	}
	
	if (conn !=null) {
		System.out.println("Done!");
	}
	else {
		System.out.println("Failed!");
	}
}
}
