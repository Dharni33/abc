package p;
import java.sql.*;


import java.util.Scanner;
public class Batchupdate {
	void show() {
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
	    String dbname= "db1";
		String driver= "com.mysql.jdbc.Driver";
		String username= "root";
		String password="root";
		
	
	
	try {
		Class.forName(driver);
		conn= DriverManager.getConnection(url+dbname,username,password);
		
		
		PreparedStatement ps = conn.prepareStatement("update emp3 set ename=? where ecode=?");
		conn.setAutoCommit(false);
		Scanner sc= new Scanner(System.in);
		String a= sc.nextLine();
		String b= sc.nextLine();
		ps.setString(1, a);
		ps.setString(2,b);
		ps.addBatch();
		
		//Scanner sc= new Scanner(System.in);
		String c= sc.nextLine();
		String d= sc.nextLine();
		ps.setString(1, c);
		ps.setString(2,d);
		ps.addBatch();
		
		int x [] = ps.executeBatch();
		for(int i:x)
		System.out.println(i +" rows inserted");
		conn.commit();

		conn.close();
		System.out.println("Disconnected from database");
		
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
		
	}
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Batchupdate i= new Batchupdate();
		i.show();
	}

}

