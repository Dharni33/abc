package p;
import java.sql.*;
public class A {
	
	void show() {
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
	    String dbname= "db1";
		String driver= "com.mysql.jdbc.Driver";
		String username= "root";
		String password="root";
		
	
	
	try {
		Class.forName(driver);
		conn= DriverManager.getConnection(url+dbname,username,password);
		Statement sm= conn.createStatement();
		ResultSet rs= sm.executeQuery("Select * from emp3");
		while(rs.next())
		{
			String f1= rs.getString(1);
			String f= rs.getString(2);
			System.out.println(f1);
			System.out.println(f);
		}
		conn.close();
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
		
	}
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A i= new A();
		i.show();
	}

}
