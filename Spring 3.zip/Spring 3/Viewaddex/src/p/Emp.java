package p;

public class Emp {
	String name;
	String ecode;
	int id;
	public String getEcode() {
		return ecode;
	}
	public void setEcode(String ecode) {
		this.ecode = ecode;
	}
	
	Emp(){}
	Emp( int id,String name,String ecode){
		this.id=id;
		this.name=name;
		this.ecode=ecode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}
