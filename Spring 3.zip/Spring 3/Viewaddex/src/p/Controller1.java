package p;

import java.awt.List;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Controller1 {
@Autowired
LoginService ls;
	@RequestMapping("/view")
	public String dis(ModelMap model) {
	ArrayList al= (ArrayList)ls.getData();
	model.addAttribute("lgobj",al);
	return "display";}
	
	
	@RequestMapping("/add")
	public String add(ModelMap model) {
	Emp emp= new Emp();
	
	model.addAttribute("lgobj",emp);
	return "add";}
	
	@RequestMapping("/save")
	public String save(@ModelAttribute("lgobj")Emp emp2, ModelMap model) {
	model.addAttribute("lgobj2",emp2);
	ls.addLoginSer(emp2);
	return "redirect:/view";}
	
	@RequestMapping("/edit/{id}")
	public String edit(@PathVariable int id, ModelMap model) {
	ArrayList<Emp> al= (ArrayList<Emp>)ls.edit2(id);
	model.addAttribute("lgobj",al);
	return "redirect:/view";}
	
	@RequestMapping(value="/del/{id}",method = RequestMethod.GET)//working
	public String delMethod(@PathVariable int id,ModelMap model)
	{
		
		ArrayList<Emp> al= (ArrayList<Emp>)ls.del(id);
		//model.addAttribute("lgobj",al);//not required
		return "redirect:/view";
	}
}

	

