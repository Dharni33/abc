package p;


import java.util.*;

import org.springframework.stereotype.Service;

@Service
public class Dao {
	List<Emp> l;
	
	public List getL() {
		return l;
	}

	public void addLogin(Emp e)
	{
		l.add(e);
		
	}
	Dao()
	{
		l=new ArrayList<Emp>();
		l.add(new Emp(1,"Dharni","001"));
		l.add(new Emp(2,"Hrishi","420"));
		l.add(new Emp(3,"Vineet","002"));
		
	}
	
	public List<Emp> editData(int id){
		Iterator itr= l.iterator();
		Emp e1;
		while(itr.hasNext()) {
			e1= (Emp)itr.next();
			if((e1.getId())==(id)) {
				e1.setName("Aastha");
				
			}
			
		}
		return l;
	}
	
	public List<Emp> delData(int id)
	   {
		
		   
		   Iterator itr=l.iterator();  
			
		  
			 while(itr.hasNext())
			{  
				 Emp lgi=(Emp)itr.next();  
				 if((lgi.getId())==(id))
				   {
					 itr.remove();
				   }
	 		}
			 return l;
}
}
