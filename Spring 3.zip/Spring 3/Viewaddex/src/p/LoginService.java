package p;

import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
@Service
public class LoginService 
{
	@Autowired
	Dao da;
	List <Emp> l;
	public List<Emp> getData()
	{
		
		return da.getL();
	}
	public void addLoginSer(Emp lgn)
	{
		da.addLogin(lgn);
	}
	
	public List<Emp> edit2(int id)
	{
		l= da.editData(id);
		return l;
	}
public List<Emp> del(int id)
	{
		l=da.delData(id);
		return l;
	}
	
}
