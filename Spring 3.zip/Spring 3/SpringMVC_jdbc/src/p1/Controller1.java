package p1;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



@Controller
public class Controller1
{
	@Autowired
	EDao dao3;
	@RequestMapping(value="/display")
	public String disData(ModelMap m)
	{
	   List l=dao3.getEmployees();
	   m.addAttribute("lobj",l);
	   return "dis1";
		
	}
	
	@RequestMapping(value="add")
	public String addRecord1(ModelMap m)
	{
		Emp e=new Emp();
		m.addAttribute("eobj",e);
		
		return "AddJDBC";
	}
	@RequestMapping(value="save1")
	public String saveJdbcRecord(@ModelAttribute("eobj")Emp eobj1)
	{
		dao3.save(eobj1);
		return "redirect:/display";
		
	}
	
	@RequestMapping(value="/edit1/{ecode}")    
    public String edit(@PathVariable String ecode, Model m){    
        Emp emp=dao3.getEmpById(ecode);    
        System.out.print("ecode="+emp.getEcode());
        m.addAttribute("eobj",emp);  
        System.out.println("in edit() ecode="+emp.getEname());
        return "empeditform";    
    }    
    /* It updates model object. */    
    @RequestMapping(value="/edit2",method= RequestMethod.POST)    
    public String editsave(@ModelAttribute("emp") Emp emp)
    {    System.out.println("in edit() ecode="+emp.ecode);
        dao3.update(emp);    
        return "redirect:/display";    
    }    
    
    @RequestMapping(value="/del1/{ecode}",method = RequestMethod.GET)    
    public String delete(@PathVariable String ecode){    
        dao3.delete(ecode);    
        return "redirect:/display";    
    }     

}
