package p1;
import org.springframework.stereotype.Service;
import java.sql.ResultSet;    
import java.sql.SQLException;    
import java.util.List;    
import org.springframework.jdbc.core.BeanPropertyRowMapper;    
import org.springframework.jdbc.core.JdbcTemplate;    
import org.springframework.jdbc.core.RowMapper; 
@Service
public class EDao 
{
	JdbcTemplate template;    
    
	public void setTemplate(JdbcTemplate template) {    
	    this.template = template;    
	}    
	public List<Emp> getEmployees(){    
	    return template.query("select * from emp3",new RowMapper<Emp>(){    
	        public Emp mapRow(ResultSet rs, int row) throws SQLException {    
	            Emp e=new Emp();    
	            e.setEcode(rs.getString(1));    
	            e.setEname(rs.getString(2));    
	            return e;    
	        }    
	    });    
	}   
	public int save(Emp p){    
	    String sql="insert into emp3(ecode,ename) values('"+p.getEcode()+"','"+p.getEname()+"')";    
	    return template.update(sql);    
	}  
	
	public Emp getEmpById(String ecode){    
	    String sql="select * from emp3 where ecode=?";    
	    return template.queryForObject(sql, new Object[]{ecode},new BeanPropertyRowMapper<Emp>(Emp.class));    
	}    
	public int update(Emp e){    
	    String sql="update emp3 set ename='"+e.getEname()+"' where ecode='"+e.getEcode()+"'";    
	    return template.update(sql);    
	}    
	public int delete(String ecode){    
	    String sql="delete from emp3 where ecode='"+ecode+"'";    
	    return template.update(sql);    
	}   
	
}
