package p;

import java.awt.List;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Controller1 {
	@RequestMapping("/v1")
	
	public ModelAndView dis() {
		String l= "Hello1";
	return new ModelAndView("view","string1",l);}
	
	@RequestMapping("/v2")
	public ModelAndView form1() {
		String l2= "Hello2";
		return new ModelAndView("display","string2",l2);
	}
	@RequestMapping("/v3")
	public ModelAndView form2() {
		String l3= "Hello3";
		return new ModelAndView("show","string3",l3);
	}
}

