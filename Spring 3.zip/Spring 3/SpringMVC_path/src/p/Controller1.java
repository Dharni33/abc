package p;

import java.awt.List;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value="/display")
public class Controller1 {
	@RequestMapping(value="/v1/{uname}/{pwd}",method=RequestMethod.GET)
	
	
	public ModelAndView dis(@PathVariable("uname")String uname, @PathVariable("pwd")String pwd, @RequestParam("city")String city) {
	return new ModelAndView("display","msg","Hello"+uname+pwd+"  "+city);}
	
	

}

