package p;
import java.util.*;
public class Quest {
	int id;
	String q;
	List<Answer1> ans;
	
	Quest(){}
	Quest(int id, String q,List<Answer1> ans){
		this.id=id;
		this.q=q;
		this.ans=ans;
		
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getQ() {
		return q;
	}

	public void setQ(String q) {
		this.q = q;
	}

	public List<Answer1> getAns() {
		return ans;
	}

	public void setAns(List<Answer1> ans) {
		this.ans = ans;
	}
	
	
	void display() {
		System.out.println(id+" "+q+" ");
		Iterator i= ans.iterator();
		System.out.println("ans are " );
		while(i.hasNext()) {
			System.out.println(i.next());

		}
	}
}

	