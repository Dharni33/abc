package p;
import java.util.*;
public class Quest {
	int id;
	String name;
	List<String> courses;
	
	Quest(){}
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public List<String> getCourses() {
		return courses;
	}


	public void setCourses(List<String> courses) {
		this.courses = courses;
	}
	void display() {
		System.out.println(id+" "+name+" ");
		Iterator i= courses.iterator();
		System.out.println("courses are " );
		while(i.hasNext()) {
			System.out.println(i.next());

		}
	}


	
}

	