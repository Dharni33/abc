package p;
import java.util.*;
public class Quest {
	int id;
	String q;
	List<Answer1> ans;
	
	Quest(int id, String q,List<Answer1> ans){
		this.id=id;
		this.q=q;
		this.ans=ans;
		
	}
	
	void display() {
		System.out.println(id+" "+q+" ");
		Iterator i= ans.iterator();
		System.out.println("ans are " );
		while(i.hasNext()) {
			System.out.println(i.next());

		}
	}
	
}
