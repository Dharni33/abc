package p;
import java.util.*;
public class A {
	
	B b1;
	
	A(B b1){
		this.b1=b1;
	}
	
	void show() {
		System.out.println("Class A test ");
		b1.show1();
	}
}
