package p;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class test {
	public static void main(String ar[]) {
		//Resource re= new ClassPathResource("applicationContext.xml");
		//BeanFactory fact= new XmlBeanFactory(re);
		ApplicationContext ct= new ClassPathXmlApplicationContext("applicationContext.xml");
		A q= (A)ct.getBean("a");
		q.show();
	}
}