package com.ContactJPA4.ContactJPA4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication

public class ContactJpa4Application {
	
	public static void main(String[] args) {
		SpringApplication.run(ContactJpa4Application.class, args);
		System.out.print("ddddddddddddd");
	}

}
