package p;
import java.sql.*;
import javax.servlet.jsp.*;
import java.util.Scanner;
import java.io.*;
import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.tagext.*;
public class Customtag_jsp extends TagSupport {
	public int doStartTag() throws JspException{
		try {
			JspWriter out=  pageContext.getOut();
			out.print("<br><b> Welcome custom tag<b>");
			
		}
		catch(Exception e) {}
			return SKIP_BODY;
	}	
	public int doEndTag() throws JspTagException{
		return SKIP_PAGE;
	}
	}

