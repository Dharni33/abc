package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class URL2 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		try{
			PrintWriter out = response.getWriter();
			String name= request.getParameter("pp");
			name= name.trim();
			out.println("your name is "+ name);
			
			
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
}
}