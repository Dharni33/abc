package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class URL1 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		try{
			PrintWriter out = response.getWriter();
			String name1= request.getParameter("user");
			name1= name1.trim();
			out.println("your name is stored please click");
			out.println("<a href='/URLServlet/2?pp= "+name1+"'>here</a>");
			
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
}
}