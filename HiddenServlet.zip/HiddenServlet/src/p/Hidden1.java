package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Hidden1 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		try{
			PrintWriter out = response.getWriter();
			String name1= request.getParameter("user");
			name1= name1.trim();
			
			out.println("<html><body>");
			out.println("<form name='iii' method='get' action='1'>");
			out.println("<input type='hidden' value='"+name1+"' name='hh'>");
			out.println("<input type='submit' value='click' name='click'>");
			out.println("</form></body></html>");
			
			
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
}
}