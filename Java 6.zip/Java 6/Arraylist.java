package p1;
import java.util.*;

public class Arraylist {
	public static void main(String ar[]) {
		ArrayList al= new ArrayList();
		System.out.println("Initial size:"+ al.size());
		al.add("Dharni");
		al.add('a');
		al.add("Shah");
		al.add("Aastha");
		al.add("Shah");
		//al.add(1,"2");
		System.out.println("After adding values size:"+ al.size());
		
		System.out.println("Contents:"+ al);
		
		al.remove("Shah");
		
		Iterator itr= al.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		System.out.println("For each");
		for(Object o:al)
		{
			System.out.println(o);
		}
	}

}
