package p1;
import java.util.*;
class Emp implements Comparable<Emp>
{
	int id;
	String name;
	
	Emp(int id, String name){
		this.id=id;
		this.name=name;
	}
	
	public String toString() {
		return id+ " "+ name;
	}
	
	public int compareTo(Emp e1) {
		/*if(e1.id == e2.id) return 0;
		else if (e1.id> e2.id) return 1;
		else return -1;*/
		
		return  name.compareTo(e1.name);
	}
}



public class CollectComparable{
	public static void main(String a[]) {
		
		Emp e1= new Emp(10,"B");
		Emp e2= new Emp(9,"A");
		
		List <Emp> s1= new ArrayList <Emp>();
		s1.add(e1);
		s1.add(e2);
		
		Collections.sort(s1);
		System.out.println(s1);
		
	}
}