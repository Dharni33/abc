package p1;
import java.util.*;
public class TreeMapEx {
	public static void main(String[] args) {

		TreeMap<Integer,String> hm = new TreeMap<Integer,String>();
		hm.put(100,"amit");
		hm.put(102,"Ravi");
		hm.put(103,"Vijay");
		hm.put(101,"Rahul");
		for(Map.Entry m : hm.entrySet())
		{
			System.out.println(m.getKey()+" "+m.getValue());
		}
	}
}
