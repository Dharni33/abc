package p1;
import java.util.*;

class Book{
	
	int id;
	String title, author, publisher;
	int qt;
	Book(int id,String title, String author,String publisher,int qt){
		this.id= id;
		this.title=title;
		this.author=author;
		this.publisher=publisher;
		
	}
}
public class HashMapEx2 {
	public static void main(String ar[]) {
		Map<Integer,Book> hm= new HashMap<Integer,Book>();
		
		Book b1 = new Book(101,"Let us C","Yashwant Kanetkar","BPB",8);
		Book b2 = new Book(102,"Let us Java","Yashwant Kanetkar","BPB",10);
		Book b3 = new Book(103,"Let us Python","Yashwant Kanetkar","BPB",11);
		
		hm.put(1,b1);
		hm.put(2,b2);
		hm.put(3,b3);
		
		System.out.println("For each o/p");
		for(Map.Entry<Integer, Book> entry1: hm.entrySet()) {
			int key =entry1.getKey();
			Book b = entry1.getValue();
			System.out.println(key+"Details:");
			System.out.println(b.id+" "+b.title+" " +b.author+" "+b.publisher);
			}
		System.out.println("Iterator o/p");
		
		Set set = hm.entrySet();
		
		Iterator i= set.iterator();
		
		while(i.hasNext()) {
			Map.Entry m= (Map.Entry)i.next();
			Book bb = (Book)m.getValue();
			System.out.println(m.getKey()+":");
			System.out.println(bb.id+" "+bb.title+" " +bb.author+" "+bb.publisher);
		}
	}
}
