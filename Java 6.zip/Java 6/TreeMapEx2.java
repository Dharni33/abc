package p1;
import java.util.*;

class Book3{
	
	int id;
	String title, author, publisher;
	int qt;
	Book3(int id,String title, String author,String publisher,int qt){
		this.id= id;
		this.title=title;
		this.author=author;
		this.publisher=publisher;
		
	}
}
public class TreeMapEx2 {
	public static void main(String ar[]) {
		TreeMap<Integer,Book3> hm= new TreeMap<Integer,Book3>();
		
		Book3 b1 = new Book3(101,"Let us C","Yashwant Kanetkar","BPB",8);
		Book3 b2 = new Book3(102,"Let us Java","Yashwant Kanetkar","BPB",10);
		Book3 b3 = new Book3(103,"Let us Python","Yashwant Kanetkar","BPB",11);
		
		hm.put(1,b1);
		hm.put(2,b2);
		hm.put(3,b3);
		
		System.out.println("For each o/p");
		for(Map.Entry<Integer, Book3> entry1: hm.entrySet()) {
			int key =entry1.getKey();
			Book3 b = entry1.getValue();
			System.out.println(key+"Details:");
			System.out.println(b.id+" "+b.title+" " +b.author+" "+b.publisher);
			}
		System.out.println("Iterator o/p");
		
		Set set = hm.entrySet();
		
		Iterator i= set.iterator();
		
		while(i.hasNext()) {
			Map.Entry m= (Map.Entry)i.next();
			Book3 bb = (Book3)m.getValue();
			System.out.println(m.getKey()+":");
			System.out.println(bb.id+" "+bb.title+" " +bb.author+" "+bb.publisher);
		}
	}
}
