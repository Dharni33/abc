package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdateServ extends HttpServlet {
    

		

	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
	    String dbname= "db1";
		String driver= "com.mysql.jdbc.Driver";
		String username= "root";
		String password="root";
		try{
			Class.forName(driver);
			PrintWriter out = response.getWriter();
			conn= DriverManager.getConnection(url+dbname,username,password);
			PreparedStatement ps = conn.prepareStatement("update emp3 set ename=? where ecode=?");
			String ecode= request.getParameter("ename");
			String ename= request.getParameter("ecode");
			ps.setString(1, ecode);
			ps.setString(2,ename);
			
			int x  = ps.executeUpdate();
			out.print(x +" rows updated");
			Statement sm= conn.createStatement();
			ResultSet rs= sm.executeQuery("Select * from emp3");
			out.print("<table border= 1 bgcolor= lightblue >");
			out.print("<th>ECODE</th><th> ENAME</th>");
			while(rs.next())
			{
				String f1= rs.getString(1);
				String f= rs.getString(2);
				//System.out.println(f1);
				//System.out.println(f);
				out.print("<tr><td>"+f1+"</td><td>"+f+"</td></tr>");
				
			}
			out.print("</table>");
			conn.close();
			out.println("Disconnected from database");
			

		}
		
		catch(Exception e){
			e.printStackTrace();
		}	
	}
}