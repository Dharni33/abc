package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Context1 extends HttpServlet {
	
	ServletContext ctx1= null;
	
	public void init(ServletConfig sc) throws ServletException{
		ctx1 = sc.getServletContext();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		try{
			PrintWriter out = response.getWriter();
			String name= request.getParameter("user");
			ctx1.setAttribute("ob",name);
			
			out.println("your name is stored");
			out.println("<form name='f1' method='get' action='pass2'>");
			out.println("<input type='submit' value='click' name='click'>");
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
}
}