package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Context2 extends HttpServlet {
	
	ServletContext ctx= null;
	
	public void init(ServletConfig sc){
		ctx = sc.getServletContext();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		try{
			PrintWriter out = response.getWriter();
			String name= (String)ctx.getAttribute("ob");
			//String name= request.getParameter("user");
			out.println("<br> Hello!"+ name);
		}
		catch(Exception e){
			e.printStackTrace();
		}
}
}