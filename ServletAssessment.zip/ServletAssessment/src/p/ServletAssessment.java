package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletAssessment extends HttpServlet {
    
	String first_name;
	String last_name;
	String emp_id;
	String address;
	static int id=1;
	
		

	public String getFirst_name() {
		return first_name;
	}



	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}



	public String getLast_name() {
		return last_name;
	}



	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}



	public String getEmp_id() {
		return emp_id;
	}



	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}

	public String generateEmpId(String fname, String lname)

	{
		String s = fname.substring(0,2)+lname.substring(0,2)+String.format("%03d", ServletAssessment.id);
		ServletAssessment.id++;
		return s;
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
	    String dbname= "db1";
		String driver= "com.mysql.jdbc.Driver";
		String username= "root";
		String password="root";
		try{
			
			PrintWriter out = response.getWriter();
			String fname= request.getParameter("fname");
			String lname= request.getParameter("lname");
			String add= request.getParameter("add");
			
			Class.forName(driver);
			conn= DriverManager.getConnection(url+dbname,username,password);
			Statement sm= conn.createStatement();
			ResultSet rs1= sm.executeQuery("Select count(*) from employee");
			rs1.next();
			int count= rs1.getInt(1);
			ServletAssessment.id= count+1;
			String emp_id = generateEmpId(fname,lname);
			//out.print(emp_id);
			
			ServletAssessment e1 = new ServletAssessment();
			e1.setFirst_name(fname);
			e1.setLast_name(lname);
			e1.setAddress(add);
			e1.setEmp_id(emp_id);
			out.println("Details recorded");
			
			Class.forName(driver);
			conn= DriverManager.getConnection(url+dbname,username,password);
			PreparedStatement ps = conn.prepareStatement("insert into employee values(?,?,?,?)");
			
			ps.setString(1, e1.getEmp_id());
			ps.setString(2, e1.getFirst_name());
			ps.setString(3, e1.getLast_name());
			ps.setString(4, e1.getAddress());
			
			int x  = ps.executeUpdate();
			out.print(x +" rows inserted");
			//Statement sm= conn.createStatement();
			ResultSet rs= sm.executeQuery("Select * from employee");
			out.print("<table border= 1 bgcolor= lightpink >");
			out.print("<th>Emp_id</th><th>First name</th><th>Last name</th><th>Address</th>");
			while(rs.next())
			{
				String f1= rs.getString(1);
				String f2= rs.getString(2);
				String f3= rs.getString(3);
				String f4= rs.getString(4);
				//System.out.println(f1);
				//System.out.println(f);
				out.print("<tr><td>"+f1+"</td><td>"+f2+"</td><td>"+f3+"</td><td>"+f4+"</td></tr>");
				
			}
			out.print("</table>");
			conn.close();
			out.println("Disconnected from database");
			}
		
		catch(Exception e){
			e.printStackTrace();
		}	
	}
}