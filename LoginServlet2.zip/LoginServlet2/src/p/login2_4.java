package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class login2_4 extends HttpServlet {
ServletContext ctx= null;
	
	public void init(ServletConfig sc){
		ctx = sc.getServletContext();
	}	
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		try{
			PrintWriter out = response.getWriter();
			String ecode= request.getParameter("ecode");
			String ename= request.getParameter("ename");
			String user= (String)ctx.getAttribute("ob");
			ctx.setAttribute("ob",user);

			//String user= request.getParameter("user");
			String button_value= request.getParameter("hh");
			//String passw= request.getParameter("password");
			out.println("<br> Welcome "+ user);
			out.println("<br>"+ button_value);
			
			Connection conn = null;
			String url = "jdbc:mysql://localhost:3306/";
		    String dbname= "db1";
			String driver= "com.mysql.jdbc.Driver";
			String username= "root";
			String password="root";
			
			Class.forName(driver);
				//PrintWriter out = response.getWriter();
			conn= DriverManager.getConnection(url+dbname,username,password);
			
			if(button_value.equals("update")) {
				PreparedStatement ps = conn.prepareStatement("update emp3 set ename=? where ecode=?");
				
				ps.setString(1,ename);
				ps.setString(2,ecode);
				int x1  = ps.executeUpdate();
				out.print(x1 +" rows updated");
				Statement sm= conn.createStatement();
				ResultSet rs= sm.executeQuery("Select * from emp3");
				out.print("<table border= 1 bgcolor= lightblue >");
				out.print("<th>ECODE</th><th> ENAME</th>");
				while(rs.next())
				{
					String f1= rs.getString(1);
					String f= rs.getString(2);
					//System.out.println(f1);
					//System.out.println(f);
					out.print("<tr><td>"+f1+"</td><td>"+f+"</td></tr>");
					
				}
				out.print("</table>");}
			else if(button_value.equals("delete")){
				out.println("DELETE");
			PreparedStatement ps = conn.prepareStatement("delete from emp3 where ename=?");
			ps.setString(1, ename);
			//ps.setString(2,ecode);
			int x1  = ps.executeUpdate();
			out.print(x1 +" rows deleted");
			Statement sm= conn.createStatement();
			ResultSet rs= sm.executeQuery("Select * from emp3");
			out.print("<table border= 1 bgcolor= lightblue >");
			out.print("<th>ECODE</th><th> ENAME</th>");
			while(rs.next())
			{
				String f1= rs.getString(1);
				String f= rs.getString(2);
				//System.out.println(f1);
				//System.out.println(f);
				out.print("<tr><td>"+f1+"</td><td>"+f+"</td></tr>");
				
			}
			out.print("</table>");}
			
			else{
			Statement sm= conn.createStatement();
			ResultSet rs= sm.executeQuery("Select * from emp3");
			out.print("<table border= 1 bgcolor= lightblue >");
			out.print("<th>ECODE</th><th> ENAME</th>");
			while(rs.next())
			{
				String f1= rs.getString(1);
				String f= rs.getString(2);
				//System.out.println(f1);
				//System.out.println(f);
				out.print("<tr><td>"+f1+"</td><td>"+f+"</td></tr>");
				
			}
			out.print("</table>");}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
		public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doGet(request,response);
			
		}
}