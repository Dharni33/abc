package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class login2_3 extends HttpServlet {
ServletContext ctx= null;
	
	public void init(ServletConfig sc){
		ctx = sc.getServletContext();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		try{
			PrintWriter out = response.getWriter();
			String user= (String)ctx.getAttribute("ob");
			ctx.setAttribute("ob",user);
			//String user= request.getParameter("user");
			String x= request.getParameter("click");
			//String passw= request.getParameter("password");
			out.println("<br> Welcome "+ user);
			
			Connection conn = null;
			String url = "jdbc:mysql://localhost:3306/";
		    String dbname= "db1";
			String driver= "com.mysql.jdbc.Driver";
			String username= "root";
			String password="root";
			
			Class.forName(driver);
				//PrintWriter out = response.getWriter();
			conn= DriverManager.getConnection(url+dbname,username,password);

				out.println("<html><body>");
				out.println("<form name='iii' method='get' action= 'pass3'>");
				out.println("<input type='text' placeholder='ECODE' name='ecode'>");
				out.println("<input type='text' placeholder='ENAME' name='ename'>");
				out.println("<input type='hidden' value='"+x+"' name='hh'>");
				out.println("<input type='submit' value='OK'>");
				out.println("</form></body></html>");
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
		public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doGet(request,response);
			
		}
}