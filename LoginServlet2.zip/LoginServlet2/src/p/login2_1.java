package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class login2_1 extends HttpServlet {
	
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
	    String dbname= "db1";
		String driver= "com.mysql.jdbc.Driver";
		String username= "root";
		String password="root";
		try{
			conn= DriverManager.getConnection(url+dbname,username,password);
			PrintWriter out = response.getWriter();
			String user= request.getParameter("user");
			user= user.trim();
			String passw= request.getParameter("password");
			passw= passw.trim();
			RequestDispatcher rd1= request.getRequestDispatcher("/login2_2");
			//RequestDispatcher rd2= request.getRequestDispatcher("/login2_3");
			
			Statement sm= conn.createStatement();
			ResultSet rs= sm.executeQuery("Select * from login where user='"+ user +"'");
			if(rs.next()) {
			String f1= rs.getString(1);
			String f= rs.getString(2);
			if(user.equals(f1) && passw.equals(f)) {
				//out.println("VALID USER");
				rd1.include(request,response);
				
			}
			else {
				out.println("INVALID USER");
				response.sendRedirect("passwordincorrect.html");
			}
			}
			else {
				response.sendRedirect("nouser.html");
			}
			
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
		public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
			doGet(request,response);
			
		}
}