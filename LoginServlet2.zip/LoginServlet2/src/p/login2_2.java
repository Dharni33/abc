package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class login2_2 extends HttpServlet {
ServletContext ctx1= null;
	
	public void init(ServletConfig sc) throws ServletException{
		ctx1 = sc.getServletContext();
	}

   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		try{
			
			PrintWriter out = response.getWriter();
			String user= request.getParameter("user");
			String passw= request.getParameter("password");
			ctx1.setAttribute("ob",user);
			out.println("<br> Hello!"+ user);
			
			out.println("<html><body>");
			out.println("<form name='iii' method='get' action='pass2'>");
			out.println("<input type='submit' value='display' name='click'>");
			out.println("<input type='submit' value='update' name='click'>");
			out.println("<input type='submit' value='insert' name='click'>");
			out.println("<input type='submit' value='delete' name='click'>");
			out.println("</form></body></html>");
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
		public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doGet(request,response);
			
		}
}