package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class F2 extends HttpServlet {
	
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		try{
			PrintWriter out = response.getWriter();
			String user= request.getParameter("user");
			String passw= request.getParameter("password");
			
			out.print("Wrong password!"+ user);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		doGet(request,response);
		
	}
}
