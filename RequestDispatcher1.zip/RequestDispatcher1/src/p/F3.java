package p;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class F3 extends HttpServlet {
	
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
	    String dbname= "db1";
		String driver= "com.mysql.jdbc.Driver";
		String username= "root";
		String password="root";
		try{
			conn= DriverManager.getConnection(url+dbname,username,password);
			PrintWriter out = response.getWriter();
			String user= request.getParameter("user");
			user= user.trim();
			String passw= request.getParameter("password");
			passw= passw.trim();
			RequestDispatcher rd1= request.getRequestDispatcher("/1");
			RequestDispatcher rd2= request.getRequestDispatcher("/2");
			
			Statement sm= conn.createStatement();
			ResultSet rs= sm.executeQuery("Select * from login where user='"+ user+"'");
			if(rs.next()) {
			String f1= rs.getString(1);
			String f= rs.getString(2);
			if(user.equals(f1) && passw.equals(f)) {
				out.println("VALID USER");
				rd1.include(request,response);
				
			}
			else {
				out.println("INVALID USER");
				rd2.forward(request,response);
			}
			}
			else {
				out.println("User does not exist");
			}
			
			
			
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
		public void doPost(HttpServletRequest request, HttpServletResponse response) {
			doGet(request,response);
			
		}
}